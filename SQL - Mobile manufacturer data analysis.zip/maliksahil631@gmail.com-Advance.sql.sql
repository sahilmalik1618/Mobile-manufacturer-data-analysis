--SQL Advance Case Study


--Q1--BEGIN 
	
select Distinct
State
from FACT_TRANSACTIONS as X
LEFT JOIN DIM_LOCATION as L
on X.IDLocation = L.IDLocation
where YEAR(Date) >= 2005

--Q1--END

--Q2--BEGIN

select top 1
State,Manufacturer_Name,SUM(Quantity) as [total Count]
from     (select 
		  Country,State,Quantity,IDModel
		  from DIM_LOCATION as L
		  right join FACT_TRANSACTIONS as F
		  on L.IDLocation = F.IDLocation
		  )as X

left join(select 
		  Manufacturer_Name,IDModel
		  from DIM_MODEL as M
		  left join DIM_MANUFACTURER as R
		  on M.IDManufacturer = R.IDManufacturer
		  )as Y
on X.IDmodel = Y.IDModel
where Country = 'US' and  Manufacturer_Name = 'Samsung'
group by State,Manufacturer_Name

--Q2--END

--Q3--BEGIN      
	
select
State,ZipCode,Model_name,tran_count
from   (
	    select 
		IDModel,ZipCode,State,count(Quantity) as tran_count
		from DIM_LOCATION as L
		right join FACT_TRANSACTIONS as F
		on L.IDLocation = F.IDLocation
		group by State,ZipCode,IDModel
	   ) as X
right join DIM_MODEL as M
on M.IDModel = X.IDModel

--Q3--END

--Q4--BEGIN

select top 1
concat("Manufacturer_Name",' ',"Model_Name") as cellphone_name,Unit_price
from DIM_MODEL as M
left join DIM_MANUFACTURER as R
on M.IDManufacturer = R.IDManufacturer
order by Unit_price  

--Q4--END

--Q5--BEGIN

select 
X.IDManufacturer,IDModel,AVG(Unit_price) as avg_price
from (
	  select top 5
	  IDManufacturer,SUM(Quantity) as tot_qty
	  from FACT_TRANSACTIONS as F    
	  left join DIM_MODEL as M
	  on F.IDmodel = M.IDModel
	  group by IDManufacturer
	  order by tot_qty desc
	  ) as X
left join DIM_MODEL as M  
on X.IDManufacturer = M.IDManufacturer
group by X.IDManufacturer,IDModel
order by avg_price 



--Q5--END

--Q6--BEGIN

select 
Customer_Name,AVG(Totalprice) as avg_spend
from DIM_CUSTOMER as C
right join FACT_TRANSACTIONS as F
on C.IDCustomer = F.IDCustomer
where YEAR(Date) = 2009
group by Customer_Name
having AVG(Totalprice) > 500

--Q6--END
	
--Q7--BEGIN  
	
select * from (	
				select * from ( 
							   select top 5 
							   Model_Name 
							   from DIM_MODEL as M
							   right join(select 
							   			  IDModel,SUM(Quantity) as count_qty
							   			  from DIM_DATE as D
							   			  right join FACT_TRANSACTIONS as F
							   			  on D.DATE = F.Date
							   			  where year(D.DATE) = 2008
							   			  group by IDModel
							   			  ) as X
							   on M.IDModel = X.IDModel
							   order by count_qty desc
							   
							   intersect
							   
							   select top 5 
							   Model_Name 
							   from DIM_MODEL as M
							   right join(select 
							   			  IDModel,SUM(Quantity) as count_qty
							   			  from DIM_DATE as D
							   			  right join FACT_TRANSACTIONS as F
							   			  on D.DATE = F.Date
							   			  where year(D.DATE) = 2009
							   			  group by IDModel
							   			  ) as X
							   on M.IDModel = X.IDModel
							   order by count_qty desc
							   ) as Y

			 intersect
			 
			 select top 5 
			 Model_Name 
			 from DIM_MODEL as M
			 right join(select 
			 			IDModel,SUM(Quantity) as count_qty
			 			from DIM_DATE as D
			 		 	right join FACT_TRANSACTIONS as F
			 			on D.DATE = F.Date
			 			where year(D.DATE) = 2010
			 			group by IDModel
			 			) as X
			 on M.IDModel = X.IDModel
			 order by count_qty desc
			 ) as Z

--Q7--END	

--Q8--BEGIN

select * from  (
				select top 1 * 
				from   (select top 2
						Manufacturer_Name,year(Date) as [year],sum(Totalprice) as total_sales
						from FACT_TRANSACTIONS as F    
						left join(select 
								  Manufacturer_Name,IDModel
								  from DIM_MODEL as M
								  left join DIM_MANUFACTURER as R
								  on M.IDManufacturer = R.IDManufacturer
								  )as Y
						on F.IDmodel = Y.IDModel
						where year(Date) = 2009
						group by Manufacturer_Name,year(Date)
						order by total_sales desc
						) as X
				order by total_sales
				
				union
				
				select top 1 *
				from   (select top 2
						Manufacturer_Name,year(Date) as [year],sum(Totalprice) as total_sales
						from FACT_TRANSACTIONS as F    
						left join(select 
								  Manufacturer_Name,IDModel
								  from DIM_MODEL as M
								  left join DIM_MANUFACTURER as R
								  on M.IDManufacturer = R.IDManufacturer
								  )as Y
						on F.IDmodel = Y.IDModel
						where year(Date) = 2010
						group by Manufacturer_Name,year(Date)
						order by total_sales desc
						) as X
				order by total_sales 
				) as Z

--Q8--END

--Q9--BEGIN
	
select distinct
Manufacturer_Name
from FACT_TRANSACTIONS as F    
left join(select 
		  Manufacturer_Name,IDModel
		  from DIM_MODEL as M
		  left join DIM_MANUFACTURER as R
		  on M.IDManufacturer = R.IDManufacturer
		  )as Y
on F.IDmodel = Y.IDModel
where year(Date) = 2010 

except

select distinct
Manufacturer_Name
from FACT_TRANSACTIONS as F    
left join(select 
		  Manufacturer_Name,IDModel
		  from DIM_MODEL as M
		  left join DIM_MANUFACTURER as R
		  on M.IDManufacturer = R.IDManufacturer
		  )as Y
on F.IDmodel = Y.IDModel
where year(Date) = 2009

--Q9--END

--Q10--BEGIN

select IDCustomer,Years,avg_spend,avg_qty,
(avg_spend - prev) / prev * 100 as percent_change
from (
	  select X.IDCustomer,Y.Years,
      Y.avg_spend,Y.avg_qty,LAG(Y.avg_spend, 1) over(partition by X.IDCustomer order by X.IDCustomer asc , Years asc) prev
      from      (
          		 select top 10 IDCustomer, AVG(TotalPrice) as avg_spend
				 from FACT_TRANSACTIONS 
				 group by IDCustomer
      			 order by avg_spend desc
      			) as X

	  left join (
	             select IDCustomer, Year(Date) as Years,
	             AVG(TotalPrice) as avg_spend,
	             AVG(Quantity)  as avg_qty
	             from FACT_TRANSACTIONS
	             group  by IDCustomer, Year(Date)
	            ) as Y
	 on X.IDCustomer = Y.IDCustomer
	 ) as Z

--Q10--END



